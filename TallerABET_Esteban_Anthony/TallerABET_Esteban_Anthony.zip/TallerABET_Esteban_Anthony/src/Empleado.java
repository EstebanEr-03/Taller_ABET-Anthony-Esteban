public class Empleado implements Comparable <Empleado>{
    String cedula,nombre;
    double sueldo;
    RolDePagos rolDePagos;

    public Empleado() {
    }

    public Empleado(String cedula, String nombre, double sueldo) {
        this.cedula = cedula;
        this.nombre = nombre;
        this.sueldo = sueldo;
    }

    public Empleado(String cedula, String nombre, double sueldo, RolDePagos rolDePagos) {
        this.cedula = cedula;
        this.nombre = nombre;
        this.sueldo = sueldo;
        this.rolDePagos = rolDePagos;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getSueldo() {
        return sueldo;
    }

    public void setSueldo(double sueldo) {
        this.sueldo = sueldo;
    }

    public RolDePagos getRolDePagos() {
        return rolDePagos;
    }

    public void setRolDePagos(RolDePagos rolDePagos) {
        this.rolDePagos = rolDePagos;
    }

    @Override
    public String toString() {
        return "\n\nEmpleado:\nNombre=" + nombre + "\nCedula=" + cedula +
                "\nSueldo=" + sueldo;
    }


    public int compareTo(Empleado o) {
        int comparedResult=cedula.compareTo(o.cedula);
        if(comparedResult>0){
            return 1;
        } else if (comparedResult<0) {
            return -1;
        } else {
            return 0;
        }
    }
}