import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collections;
import java.util.List;

public class InterfazPrograma extends JFrame{
    private JScrollBar scrollBar1;
    private JPanel panelPrincipal;
    private JTabbedPane tabbedPane1;
    private JTabbedPane tabbedPane2;
    private JTabbedPane tabbedPane3;
    private JTextField textFieldInNombre;
    private JTextField textFieldInCedula;
    private JTextField textFieldInSueldo;
    private JButton crearButtonInEmpleado;
    private JTextField textFieldMoNombre;
    private JTextField textFieldMoCedula;
    private JTextField textFieldMoSueldo;
    private JTextField textFieldMoBuscarCedula;
    private JButton ButtonMoModificar;
    private JButton ButtonMoBuscarCedula;
    private JTextArea textAreaVisualizarER;
    private JButton ButtonVisualizarER;
    private JTextArea textAreaRolDePagos;
    private JButton visualizarRolDePagos;
    Empleado nuevoEmpleado;
    system newSystem=new system();
public InterfazPrograma() {
    add(panelPrincipal);
    setSize(500,500);
    setLocationRelativeTo(null);
    setTitle("Proyecto ABET ESTEBAN & ANTHONY");
    desActivarModificar();
    crearButtonInEmpleado.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (textFieldInCedula.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "El campo de cédula está vacío");
            } else if (textFieldInNombre.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "El campo de nombre está vacío");
            } else if (textFieldInSueldo.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "El campo de sueldo está vacío");
            }  else {
                int cedula;
                try {
                    cedula = Integer.parseInt(textFieldInCedula.getText());
                } catch (NumberFormatException s) {
                    JOptionPane.showMessageDialog(null, "La cédula debe ser un número válido");
                    return; // Salir del método si la cédula no es válida
                }
                if (newSystem.searchBinary(newSystem.empleadosRegistrados, cedula) == null) {
                    if (!textFieldInNombre.getText().isEmpty() && !textFieldInCedula.getText().isEmpty() && !textFieldInSueldo.getText().isEmpty()) {
                        nuevoEmpleado = new Empleado(textFieldInCedula.getText(), textFieldInNombre.getText(), Double.valueOf(textFieldInSueldo.getText()));
                        newSystem.registrarEmpleado(nuevoEmpleado);
                        JOptionPane.showMessageDialog(null, "Se ha creado con éxito el empleado");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Ya existe un empleado con ese número de cédula");
                }
            }
        }
    });
    ButtonMoModificar.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (newSystem.searchBinary(newSystem.empleadosRegistrados,Integer.valueOf(textFieldMoBuscarCedula.getText()))!=null){
                activarModificar();
                newSystem.modificarDatosEmpleado(newSystem.searchBinary(newSystem.empleadosRegistrados,Integer.valueOf(textFieldMoBuscarCedula.getText())),Double.valueOf(textFieldMoSueldo.getText()),textFieldMoCedula.getText(),textFieldMoNombre.getText());
                newSystem.empleadosRegistrados=newSystem.empleadosRegistradosConRolPagos;
                Collections.sort(newSystem.empleadosRegistrados);
            }else {
                JOptionPane.showMessageDialog(null, "No existe esa cedula");

            }
        }
    });
    ButtonVisualizarER.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            textAreaVisualizarER.setText(""+newSystem.mostrarListaDeEmpleados(newSystem.empleadosRegistrados,false));
            //textAreaVisualizarER.setText(imprimirListaRegistroEmpleados(newSystem.empleadosRegistrados));
        }
    });
    visualizarRolDePagos.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            textAreaRolDePagos.setText(""+newSystem.mostrarListaDeEmpleados(newSystem.calcularRol(newSystem.empleadosRegistradosConRolPagos),true) );
            //textAreaRolDePagos.setText(imprimirListaRegistroEmpleadosRol(newSystem.empleadosRegistradosConRolPagos));
        }
    });
}
public void activarModificar(){
        textFieldMoNombre.setEnabled(true);
        textFieldMoCedula.setEnabled(true);
        textFieldMoSueldo.setEnabled(true);
    }
public void desActivarModificar(){
        textFieldMoNombre.setEnabled(false);
        textFieldMoCedula.setEnabled(false);
        textFieldMoSueldo.setEnabled(false);
    }
    public String imprimirListaRegistroEmpleados(List<Empleado> imprimirLista){
    String respuesta=" ";
    for (Empleado empleadoRegistrado:imprimirLista)
        {
            return respuesta=" "+empleadoRegistrado.getNombre()+empleadoRegistrado.getCedula()+empleadoRegistrado.getSueldo();
        }
        return respuesta;
    }
    public String imprimirListaRegistroEmpleadosRol(List<Empleado> imprimirLista){
    String respuesta=" ";
    for (Empleado empleadoRegistradoRol:imprimirLista)
        {
            return respuesta=" "+empleadoRegistradoRol.getNombre()+empleadoRegistradoRol.getCedula()+empleadoRegistradoRol.getSueldo()+empleadoRegistradoRol.getRolDePagos();
        }
    return respuesta;
    }
}
