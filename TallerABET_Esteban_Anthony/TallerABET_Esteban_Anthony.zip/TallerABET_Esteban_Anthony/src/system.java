import javax.swing.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
public class system {
    List<Empleado> empleadosRegistrados=new ArrayList<>();
    List<Empleado> empleadosRegistradosConRolPagos=new ArrayList<>();

    public system() {
    }
    public void registrarEmpleado(Empleado empleadoRegistrar){
        empleadosRegistrados.add(empleadoRegistrar);
        empleadosRegistradosConRolPagos.add(empleadoRegistrar);
        Collections.sort(empleadosRegistrados);
        Collections.sort(empleadosRegistradosConRolPagos);
    }
    public void modificarDatosEmpleado(Empleado empleadoModificar,Double sueldo,String cedula,String nombre){
        //if (searchBinary(system.empleadosRegistrados,cedula)!=null){entra lo de abajo}
        if (sueldo!=null) {
            empleadoModificar.setSueldo(sueldo);
            JOptionPane.showMessageDialog(null,"Se ha modificado con exito el sueldo");
        }if(!nombre.isEmpty()){
            empleadoModificar.setNombre(nombre);
            JOptionPane.showMessageDialog(null,"Se ha modificado con exito el nombre");
        }if(!cedula.isEmpty()){
            empleadoModificar.setCedula(cedula);
            JOptionPane.showMessageDialog(null,"Se ha modificado con exito la cedula");
        }
    }
    public  Empleado searchBinary(List<Empleado> buscarEmpleadoPorCedulaLista, int targetTrackingCedula) {
        int izquierda=0, derecha= buscarEmpleadoPorCedulaLista.size() -1;
        while (izquierda<=derecha){
            int numMedio=(derecha+izquierda)/2;
            if(targetTrackingCedula==Integer.parseInt(buscarEmpleadoPorCedulaLista.get(numMedio).getCedula())){
                return buscarEmpleadoPorCedulaLista.get(numMedio);
            }else if(Integer.parseInt(buscarEmpleadoPorCedulaLista.get(numMedio).getCedula())<targetTrackingCedula){
                izquierda=numMedio+1;
            }else{
                derecha=numMedio-1;
            }
        }
        return null;
    }
    public String mostrarListaDeEmpleados(List<Empleado> empleadosRegistradosLista,boolean rolPagos){
        String respuesta=" ";

        for (Empleado empleadoRegistrado:empleadosRegistradosLista)
        {
            if (empleadoRegistrado.getRolDePagos()!=null && rolPagos){
               respuesta+= empleadoRegistrado.toString().concat("\n"+empleadoRegistrado.getRolDePagos());
            }else{
                respuesta=empleadosRegistradosLista.toString();
                break;
            }
        }
        return respuesta;
    }
    public List<Empleado> calcularRol(List<Empleado> empleadosCalcularImpuesto){
        Empleado empleadoConRolDePagos=null;
        double sueldoNuev=0;
        for (Empleado empleadoRecorreFor:empleadosCalcularImpuesto){
            if (empleadoRecorreFor.getSueldo()<=5000){
                empleadoRecorreFor.setRolDePagos(new RolDePagos(empleadoRecorreFor.getSueldo()*0.0935,0.0));
                sueldoNuev=empleadoRecorreFor.getSueldo()-(empleadoRecorreFor.getSueldo()*0.0935);
                empleadoRecorreFor.setSueldo(sueldoNuev);
                //empleadoConRolDePagos=empleadoRecorreFor;
                //return empleadoConRolDePagos;
            }else if (empleadoRecorreFor.getSueldo()>5000 && empleadoRecorreFor.getSueldo()<=10000){
                empleadoRecorreFor.setRolDePagos(new RolDePagos(empleadoRecorreFor.getSueldo()*0.0935,(empleadoRecorreFor.getSueldo()-5000)*0.10));
                sueldoNuev=empleadoRecorreFor.getSueldo()-(empleadoRecorreFor.getSueldo()*0.0935)-((empleadoRecorreFor.getSueldo()-5000)*0.10);
                empleadoRecorreFor.setSueldo(sueldoNuev);
                //empleadoConRolDePagos=empleadoRecorreFor;
                //return empleadoConRolDePagos;
            }else if (empleadoRecorreFor.getSueldo()>10000 && empleadoRecorreFor.getSueldo()<=18000){
                empleadoRecorreFor.setRolDePagos(new RolDePagos(empleadoRecorreFor.getSueldo()*0.0935,(empleadoRecorreFor.getSueldo()-10000)*0.20));
                sueldoNuev=empleadoRecorreFor.getSueldo()-(empleadoRecorreFor.getSueldo()*0.0935)-((empleadoRecorreFor.getSueldo()-10000)*0.20);
                empleadoRecorreFor.setSueldo(sueldoNuev);
                //empleadoConRolDePagos=empleadoRecorreFor;
                //return empleadoConRolDePagos;
            }else{
                empleadoRecorreFor.setRolDePagos(new RolDePagos(empleadoRecorreFor.getSueldo()*0.0935,(empleadoRecorreFor.getSueldo()-18000)*0.30));
                sueldoNuev=empleadoRecorreFor.getSueldo()-(empleadoRecorreFor.getSueldo()*0.0935)-((empleadoRecorreFor.getSueldo()-18000)*0.30);
                empleadoRecorreFor.setSueldo(sueldoNuev);
                //empleadoConRolDePagos=empleadoRecorreFor;
                //return empleadoConRolDePagos;
            }
        }
        return empleadosCalcularImpuesto;
    }
}
