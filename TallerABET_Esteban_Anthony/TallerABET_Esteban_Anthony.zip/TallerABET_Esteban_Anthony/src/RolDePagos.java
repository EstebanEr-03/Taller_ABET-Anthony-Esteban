public class RolDePagos {
    double aporteSeguro,ImpuestoRenta;

    public RolDePagos(double aporteSeguro, double impuestoRenta) {
        this.aporteSeguro = aporteSeguro;
        ImpuestoRenta = impuestoRenta;
    }

    public double getAporteSeguro() {
        return aporteSeguro;
    }

    public void setAporteSeguro(double aporteSeguro) {
        this.aporteSeguro = aporteSeguro;
    }

    public double getImpuestoRenta() {
        return ImpuestoRenta;
    }

    public void setImpuestoRenta(double impuestoRenta) {
        ImpuestoRenta = impuestoRenta;
    }

    @Override
    public String toString() {
        return "RolDePagos{" +
                "aporteSeguro=" + aporteSeguro +
                ", ImpuestoRenta=" + ImpuestoRenta +
                '}';
    }
}
